package com.example.lab;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabApplicationTests {
}



